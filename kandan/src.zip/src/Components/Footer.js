import '../App.css';

const Footer = () => {
    
    return <footer className="footer">Copyright © Kandan</footer>
}

export default Footer;